# AI 리터러시 VR 퀴즈 스튜디오 교사용 배포본

이 폴더는 선생님들이 GitHub Pages에 올려 바로 사용할 수 있는 정적 웹사이트 배포본입니다.

## 포함된 주요 파일

- index.html: 학생용 VR/AR 콘텐츠 시작 파일
- teacher-editor.html: 교사용 편집기
- src/data/quizData.json: 퀴즈 데이터
- src/data/surveyData.json: 설문 데이터
- src/data/themeConfig.json: 제목, 색상, 영상 설정
- assets/: 영상, 3D 자산, 기타 리소스

## 가장 쉬운 사용 흐름

1. GitHub에서 새 저장소를 만듭니다.
2. 이 폴더 안의 파일 전체를 저장소에 업로드합니다.
3. Settings > Pages에서 GitHub Pages를 켭니다.
4. 배포 주소를 확인합니다.
5. 수정이 필요하면 GitHub에서 파일을 수정하고 Commit changes를 누릅니다.

## 주의

- 이 폴더 자체를 웹사이트 루트로 올려야 합니다.
- index.html이 저장소의 가장 바깥에 있어야 합니다.
- .zip 파일 그대로 올리는 것이 아니라, 압축을 풀고 안의 파일들을 올려야 합니다.
